<!DOCTYPE html>
<html>
	<head>
		<title>PDF Checked</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

		<style type="text/css">
			html, body, div {
				font-family: common, sans-serif;
			}
		</style>
	</head>
	<body>
		<table border="1" width="80%" align="center">
			<thead>
				<tr>
					<th colspan="2">PDF Checked</th>
				</tr>
			</thead>

			<tbody>
				<tr>
					<td>Dew Hunt</td>
					<td>সালমান সাব্বির শিশির</td>
				</tr>
			</tbody>
		</table>
	</body>
</html>