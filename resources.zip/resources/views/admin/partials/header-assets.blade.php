<!-- This page CSS -->
<!-- chartist CSS -->
<link href="{{ asset('/public/admin-elite/assets/node_modules/morrisjs/morris.css') }}" rel="stylesheet">
<link href="{{ asset('/public/admin-elite/assets/node_modules/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('/public/admin-elite/assets/node_modules/bootstrap/dist/css/bootstrap-theme.min.css') }}" rel="stylesheet">

<link href="{{ asset('/public/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')  }}" rel="stylesheet">

<link href="{{ asset('/public/admin-elite/dist/css/chosen.css') }}" rel="stylesheet">
<!--Toaster Popup message CSS -->
<link href="{{ asset('/public/admin-elite/assets/node_modules/toast-master/css/jquery.toast.css') }}" rel="stylesheet">

<!-- Custom CSS -->
<link href="{{ asset('/public/admin-elite/dist/css/style.css') }}" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->


<!--alerts CSS -->
<link href="{{ asset('/public/admin-elite/assets/node_modules/sweetalert/sweetalert.css') }}" rel="stylesheet" type="text/css">

<!--switchery switch CSS -->
<link href="{{ asset('/public/admin-elite/assets/node_modules/switchery/dist/switchery.min.css') }}" rel="stylesheet" />


<!-- summernotes CSS -->
<link href="{{ asset('/public/admin-elite/assets/node_modules/summernote/dist/summernote.css') }}" rel="stylesheet" />


<!-- skin.min.css -->
<link href="{{ asset('/public/admin-elite/tinymce/skins/lightgray/skin.min.css') }}" rel="stylesheet" />

<!-- Summernote with Bootstrap 4 -->
<link href="{{ asset('/public/admin-elite/summernote/summernote-bs4.css') }}" rel="stylesheet" />

<!-- tagsinput CSS -->
<link href="{{ asset('/public/admin-elite/assets/node_modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.css') }}" rel="stylesheet">

<!-- Tree Menu CSS -->
<link href="{{ asset('/public/tree-menu/TreeMenu.css') }}" rel="stylesheet">