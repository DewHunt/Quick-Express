<div class="tiny-footer">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="copyright-block">
					<p>
						&copy; {{ date('Y') }} All Rights Reserved By <a href="{{ $website_information->website_link }}" title="exelsure courier service">{{ @$website_information->website_name }}</a>. || 
						Developed By <a href="{{ $website_information->developer_website_link }}" title="exelsure courier service">{{ @$website_information->developed_by }}</a>.
					</p>
				</div>
			</div>
			<div class="col-md-4 text-right">
				<div class="copyright-social">
					<ul>
						<li class="policy"><a href="#" title="Privacy Policy">Privacy Policy </a></li>
						<li><a href="#" title="Terms &amp; Conditions"> Terms &amp; Conditions </a></li>
						<li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>