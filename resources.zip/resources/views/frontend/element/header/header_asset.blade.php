<!-- Bootstrap CSS -->
<link rel="stylesheet" href="{{ asset('public/frontend/asset/css/bootstrap.min.css') }}" type="text/css" />

<link href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.2/css/bootstrap.css" rel="stylesheet"/>
<link href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.7.14/css/bootstrap-datetimepicker.css" rel="stylesheet"/>

<link href="{{ asset('/public/admin-elite/dist/css/chosen.css') }}" rel="stylesheet">

<!-- Navigation CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('public/frontend/asset/css/menumaker.css') }}" />

<!-- Animated CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('public/frontend/asset/css/animate.css') }}" />
<!-- Owl Carousel css -->

<link rel="stylesheet" type="text/css" href="{{ asset('public/frontend/asset/css/owl.carousel.min.css') }}" />

<!-- Line Awesome CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('public/frontend/asset/css/line-awesome.min.css') }}" />

<!-- Flaticon CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('public/frontend/asset/css/flaticon.css') }}" />

<!-- Slicknav CSS -->
<link rel="stylesheet" type="text/css" href="{{ asset('public/frontend/asset/css/slicknav.min.css') }}" />

<!-- Main Style CSS -->
<link href="{{ asset('public/frontend/asset/css/style.css') }}" rel="stylesheet" type="text/css" />

<!-- Custom Style CSS by developer -->
<link href="{{ asset('public/frontend/asset/css/custom_style.css') }}" rel="stylesheet" type="text/css" />

<!-- Responsive CSS -->
<link href="{{ asset('public/frontend/asset/css/responsive.css') }}" rel="stylesheet">

{{-- fontawsome css --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

{{-- data table css --}}
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.bootstrap.min.css">