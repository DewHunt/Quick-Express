@extends('frontend.biker.index') 

@section('biker_content')
	<div class="card cart-container">
        <h4>Dashboard Details</h4>
        
    </div>
@endsection