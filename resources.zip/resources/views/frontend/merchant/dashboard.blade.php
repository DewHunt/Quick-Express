@extends('frontend.merchant.index') 

@section('merchant_content')
	<div class="card cart-container">
        <h4>Dashboard Details</h4>
        
    </div>
@endsection