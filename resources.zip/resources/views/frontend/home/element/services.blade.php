<div id="services" class="services-main-block">
	<div class="container-fluid">
		<div class="row no-gutters">
			<div class="col-lg-4">
				<div class="services-dtl">
					<div class="section">
						<h1 class="section-heading text-white">Our Services</h1>
						<p>There anyone who loves or pursues nor desires to obtain pain of itself, bet it is pain, but because desires to obtain pain of the hellium.</p>
					</div>
					<a href="services.html" class="btn btn-secondary" title="read more">Read More<i class="las la-arrow-right"></i></a>
				</div>
			</div>
			<div class="col-lg-8">
				<div class="service-block" style="background-image: url('{{ asset('public/frontend/asset') }}/images/bg/service-bg.jpg')">
					<div class="overlay-bg"></div>
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="service-dtl-icon">
								<div class="row">
									<div class="offset-xl-2 col-lg-2">
										<div class="service-icon">
											<i class="flaticon-delivery-man"></i>
										</div>
									</div>
									<div class="offset-lg-2 offset-xl-0 col-lg-8">
										<div class="service-dtl">
											<h4 class="service-heading"><a href="services-details.html" title="standard courier">Standard</a></h4>
											<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="service-dtl-icon">
								<div class="row">
									<div class="offset-xl-2 col-lg-2">
										<div class="service-icon">
											<i class="flaticon-truck"></i>
										</div>
									</div>
									<div class="offset-lg-2 offset-xl-0 col-lg-8">
										<div class="service-dtl">
											<h4 class="service-heading"><a href="services-details.html" title="express courier">Express</a></h4>
											<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="service-dtl-icon">
								<div class="row">
									<div class="offset-xl-2 col-lg-2">
										<div class="service-icon">
											<i class="flaticon-package"></i>
										</div>
									</div>
									<div class="offset-lg-2 offset-xl-0 col-lg-8">
										<div class="service-dtl">
											<h4 class="service-heading"><a href="services-details.html" title="door to door courier">Door to Door</a></h4>
											<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="service-dtl-icon">
								<div class="row">
									<div class="offset-xl-2 col-lg-2">
										<div class="service-icon">
											<i class="flaticon-cart"></i>
										</div>
									</div>
									<div class="offset-lg-2 offset-xl-0 col-lg-8">
										<div class="service-dtl">
											<h4 class="service-heading"><a href="services-details.html" title="ware housing courier">Ware Housing</a></h4>
											<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
