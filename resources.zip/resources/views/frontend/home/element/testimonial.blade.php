<div id="testimonial" class="testimonial-main-block" style="background-image: url('{{ asset('public/frontend/asset') }}/images/bg/clients.jpg')">
	<div class="container">
		<div class="section text-center">
			<h1 class="section-heading">Customer Feedback</h1>
		</div>
		<div id="testimonial-block-slider" class="testimonial-block-slider owl-carousel">
			<div class="item testimonial-dtl">
				<div class="testimonial-client-img">
					<img src="{{ asset('public/frontend/asset') }}/images/testimonial/client-01.png" class="img-fluid" alt="testimonial">
					<i class="las la-quote-right"></i>
				</div>
				<p>“ There anyone who loves or pursues nor desires to obtain pain of itself, bet it is pain, but because occasionally can packages as their default all the Lorem Ipsum generators on the Internet tend to repeat predefined. ”</p>
				<div class="rating">
					<ul>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>

					</ul>
				</div>
				<div class="testimonial-name">Mosis Kruew</div>
			</div>
			<div class="item testimonial-dtl">
				<div class="testimonial-client-img">
					<img src="{{ asset('public/frontend/asset') }}/images/testimonial/client-02.png" class="img-fluid" alt="testimonial">
					<i class="las la-quote-right"></i>
				</div>
				<p>“ There anyone who loves or pursues nor desires to obtain pain of itself, bet it is pain, but because occasionally can packages as their default all the Lorem Ipsum generators on the Internet tend to repeat predefined. ”</p>
				<div class="rating">
					<ul>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
					</ul>
				</div>
				<div class="testimonial-name">Mona Kruew</div>
			</div>
			<div class="item testimonial-dtl">
				<div class="testimonial-client-img">
					<img src="{{ asset('public/frontend/asset') }}/images/testimonial/client-03.png" class="img-fluid" alt="testimonial">
					<i class="las la-quote-right"></i>
				</div>
				<p>“ There anyone who loves or pursues nor desires to obtain pain of itself, bet it is pain, but because occasionally can packages as their default all the Lorem Ipsum generators on the Internet tend to repeat predefined. ”</p>
				<div class="rating">
					<ul>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
						<li><i class="las la-star"></i></li>
					</ul>
				</div>
				<div class="testimonial-name">Yena Kruew</div>
			</div>
		</div>
	</div>
</div>