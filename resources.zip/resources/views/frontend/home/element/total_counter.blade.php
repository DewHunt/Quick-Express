<div id="facts" class="facts-main-block" style="background-image: url('images/bg/facts-bg.html')">
	<div class="container">
		<div class="row no-gutters text-white">
			<div class="col-lg-3 col-md-3 col-sm-6">
				<div class="facts-block text-center mrg-btm-30">
					<h1 class="facts-heading text-white counter">2150</h1><span>+</span>
					<div class="facts-heading-sign text-white"></div>
					<div class="facts-dtl">Satisfied Clients</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6">
				<div class="facts-block text-center mrg-btm-30">
					<h1 class="facts-heading text-white counter">100</h1>
					<div class="facts-heading-sign text-white"></div>
					<div class="facts-dtl">Offices Worldwide</div>
				</div>
			</div>

			<div class="col-lg-3 col-md-3 col-sm-6">
				<div class="facts-block text-center mrg-btm-30">
					<h1 class="facts-heading text-white counter">55</h1>
					<div class="facts-dtl">Countries Covered</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6">
				<div class="facts-block text-center mrg-btm-30">
					<h1 class="facts-heading text-white counter">4.6</h1>
					<div class="facts-heading-sign text-white"></div>
					<div class="facts-dtl">Reviews</div>
				</div>
			</div>
		</div>
	</div>
</div>