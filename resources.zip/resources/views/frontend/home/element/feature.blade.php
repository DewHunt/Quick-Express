<div id="features" class="features-main-block" style="background-image: url('{{ asset('public/frontend/asset') }}/images/bg/best-bg.jpg')">
	<div class="container">
		<div class="section text-center">
			<h1 class="section-heading">We Give Our Best</h1>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="features-block">
					<div class="features-img">
						<a href="#" title="Real Time Status"><img src="{{ asset('public/frontend/asset') }}/images/feature/01.jpg" class="img-fluid-img" alt="Real Time Status"></a>
					</div>
					<div class="features-dtl">
						<div class="features-meta">
							<a href="#" title="Innovation">Innovation</a>
						</div>
						<h4 class="features-heading"><a href="#" title="Real Time Status">Free Estimate</a></h4>
						<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="features-block">
					<div class="features-img">
						<a href="#" title="Expert Help"><img src="{{ asset('public/frontend/asset') }}/images/feature/02.jpg" class="img-fluid-img" alt="Expert Help"></a>
					</div>
					<div class="features-dtl">
						<div class="features-meta">
							<a href="#" title="Service">Service</a>
						</div>
						<h4 class="features-heading"><a href="#" title="Expert Help">24/7 Services</a></h4>
						<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="features-block">
					<div class="features-img">
						<a href="#" title="No Hidden Fees"><img src="{{ asset('public/frontend/asset') }}/images/feature/03.jpg" class="img-fluid-img" alt="No Hidden Fees"></a>
					</div>
					<div class="features-dtl">
						<div class="features-meta">
							<a href="#" title="Simplicity">Simplicity</a>
						</div>
						<h4 class="features-heading"><a href="#" title="No Hidden Fees">Flat Rate Fees</a></h4>
						<p>It is a long established fact that and reader will by the readable based of content page banned.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>