<div id="clients" class="clients-main-block">
	<div class="container">
		<div class="row">
			<div id="clients-slider" class="clients-slider owl-carousel">
				<div class="item-clients-img">
					<img src="{{ asset('public/frontend/asset') }}/images/clients/01.png" class="img-fluid" alt="clients-1">
				</div>
				<div class="item-clients-img">
					<img src="{{ asset('public/frontend/asset') }}/images/clients/02.png" class="img-fluid" alt="clients-2">
				</div>
				<div class="item-clients-img">
					<img src="{{ asset('public/frontend/asset') }}/images/clients/03.png" class="img-fluid" alt="clients-3">
				</div>
				<div class="item-clients-img">
					<img src="{{ asset('public/frontend/asset') }}/images/clients/04.png" class="img-fluid" alt="clients-4">
				</div>
				<div class="item-clients-img">
					<img src="{{ asset('public/frontend/asset') }}/images/clients/05.png" class="img-fluid" alt="clients-4">
				</div>
			</div>
		</div>
	</div>
</div>